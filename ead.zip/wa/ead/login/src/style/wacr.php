<style>
    .jss22 {
        background:<?php echo $wacr['lg_cor_fundo']?> !important;
    }
    .bt_txt{
        color:<?php echo $wacr['lg_cor_texto_bt']?> !important;
    }
    .btn-login .bt_txt:hover{
        color:<?php echo $wacr['lg_cor_texto_hover_bt']?> !important;
    }
    .text2, .material-icons{
        color:<?php echo $wacr['lg_cor_texto']?> !important;
    }
    .btn-login{
        background:<?php echo $wacr['lg_cor_fundo_bt']?> !important;
    }
    .btn-login:hover{
        background:<?php echo $wacr['lg_cor_fundo_hover_bt']?> !important;
        color:<?php echo $wacr['lg_cor_texto_hover_bt']?> !important;
    }
    
</style>