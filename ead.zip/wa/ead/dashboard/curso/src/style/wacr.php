    <style>
        /*.jss43{ 
            border: solid <?php echo $wacr['cor_primaria'];?> 1px  !important;
            background-color: <?php echo $wacr['ds_cor_fundo'];?> !important;
        }
        .MuiIconButton-root{ 
            color: <?php echo $wacr['cor_primaria'];?> !important; 
        }
        .profile-menu-item-icon{ 
            color: <?php echo $wacr['cor_primaria'];?> !important;
        }
        .list-channels-item-icon{
            color: <?php echo $wacr['cor_primaria'];?> !important;
        }
        .jss89 .course-header-icon-expand{
            color: <?php echo $wacr['cor_primaria'];?> !important;
        }
        .jss26{ 
            background-color: <?php echo $wacr['ds_cor_fundo'];?> !important;
        }
        .MuiPaper-root{
            background-color: <?php echo $wacr['ds_cor_fundo'];?> !important;
        }
        .jss59.grid .content{
            background-color: <?php echo $wacr['ds_cor_fundo'];?> !important;
        }
        .jss86>.section-title, .jss85{
            background-color: <?php echo $wacr['ds_cor_fundo'];?> !important;
        }
        .jss83>.section{
            background-color: <?php echo $wacr['ds_cor_fundo'];?> !important;
        }
        .MuiTypography-root, .MuiFormLabel-root{
            color: <?php echo $wacr['ds_cor_titulo'];?> !important;
        }
        .MuiTypography-root i{
            color: <?php echo $wacr['ds_descricao'];?> !important;
        }
        .jss89 .course-header-text-teacher{
            color: <?php echo $wacr['ds_descricao'];?> !important;
        }
        .MuiButton-textPrimary{
            color: <?php echo $wacr['cor_secundaria'];?> !important;
        }
        b{
            color: <?php echo $wacr['cor_secundaria'];?> !important;
        }*/
        .jss71 .btn-conclusion:not(.completed) .btn-conclusion-icon, .jss71 .btn-conclusion:not(.completed) .btn-conclusion-text, .MuiButton-textPrimary, .jss77 .course-progress-text {
            color:<?php echo $wacr['destaque'];?> !important;
        }
        @media (min-width: 960px){
            .jss67>.content>.content-wrapper>.content-scrollable::-webkit-scrollbar-thumb {
                background-color: <?php echo $wacr['destaque'];?> !important;
            }
        }
        .jss77 .course-progress-bar-fill{
            background-color: <?php echo $wacr['destaque'];?> !important;
        }
    </style>